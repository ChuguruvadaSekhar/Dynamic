import { FormFieldsDirective } from './form-fields.directive';

describe('FormFieldsDirective', () => {
  it('should create an instance', () => {
    const directive = new FormFieldsDirective();
    expect(directive).toBeTruthy();
  });
});
